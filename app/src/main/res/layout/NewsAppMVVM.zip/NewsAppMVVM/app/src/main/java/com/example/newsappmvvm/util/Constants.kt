package com.example.newsappmvvm.util

interface Constants {

    companion object{

        const val API_KEY = "6953a7421bb749c589e687746c85eee8"
        const val BASE_URL = "https://newsapi.org"
        const val Search_News_Time_Delay = 500L
    }
}