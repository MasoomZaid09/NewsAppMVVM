package com.example.newsappmvvm.models


data class Source(
    val id: Any,
    val name: String
)